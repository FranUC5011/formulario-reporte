﻿
using System;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

using SIMMNI.Datos;

using ClosedXML.Excel;

using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

using WordDocument = DocumentFormat.OpenXml.Wordprocessing.Document;
using WordText = DocumentFormat.OpenXml.Wordprocessing.Text;
using WordColor = DocumentFormat.OpenXml.Wordprocessing.Color;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;

namespace SIMMNI.Formularios
{
    public partial class FrmReportes : Form
    {
        private readonly ReportesDAO dao = new ReportesDAO();

        // Variables para la impresión PDF
        private PrintDocument documento;
        private int indiceFilaImpresion;
        private int numeroPagina;
        private DataGridView gridImpresion;
        private string tituloImpresion;

        private readonly DrawingFont fuenteTitulo =
            new DrawingFont("Arial", 15, FontStyle.Bold);

        private readonly DrawingFont fuenteNormal =
            new DrawingFont("Arial", 9);

        private readonly DrawingFont fuenteEncabezado =
            new DrawingFont("Arial", 9, FontStyle.Bold);

        public FrmReportes()
        {
            InitializeComponent();
        }

        private void FrmReportes_Load(object sender, EventArgs e)
        {
            try
            {
                cmbReporte.Items.Clear();

                cmbReporte.Items.Add("Pacientes registrados");
                cmbReporte.Items.Add("Padecimientos registrados");
                cmbReporte.Items.Add("Medicamentos registrados");
                cmbReporte.Items.Add("Historial de tomas");
                cmbReporte.Items.Add("Medicamentos próximos a vencer");
                cmbReporte.Items.Add("Medicamentos vencidos");

                cmbReporte.SelectedIndex = 0;

                CargarContadores();

                dgvReportes.AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.DisplayedCells;

                dgvReportes.ReadOnly = true;
                dgvReportes.AllowUserToAddRows = false;
                dgvReportes.AllowUserToDeleteRows = false;
                dgvReportes.SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect;

            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al iniciar el formulario de reportes:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =========================================================
        // CONTADORES
        // =========================================================

        private void CargarContadores()
        {
            try
            {
                lblTotalPacientes.Text =
                    dao.ContarPacientes().ToString();

                lblTotalMedicamentos.Text =
                    dao.ContarMedicamentos().ToString();

                lblTotalHistorial.Text =
                    dao.ContarHistorial().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los contadores:\n" + ex.Message,
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // =========================================================
        // GENERAR REPORTE
        // =========================================================

        private void GenerarReporte()
        {
            try
            {
                if (cmbReporte.SelectedIndex < 0)
                {
                    MessageBox.Show(
                        "Seleccione un tipo de reporte.",
                        "Aviso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DataTable tabla = null;

                switch (cmbReporte.Text)
                {
                    case "Pacientes registrados":
                        tabla = dao.ReportePacientes();
                        break;

                    case "Padecimientos registrados":
                        tabla = dao.ReportePadecimientos();
                        break;

                    case "Medicamentos registrados":
                        tabla = dao.ReporteMedicamentos();
                        break;

                    case "Historial de tomas":
                        tabla = dao.ReporteHistorial();
                        break;

                    case "Medicamentos próximos a vencer":
                        tabla = dao.ReporteMedicamentosProximosAVencer();
                        break;

                    case "Medicamentos vencidos":
                        tabla = dao.ReporteMedicamentosVencidos();
                        break;
                }

                if (tabla == null)
                {
                    MessageBox.Show(
                        "No se pudo obtener la información del reporte.",
                        "Aviso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                dgvReportes.DataSource = tabla;

                if (tabla.Rows.Count == 0)
                {
                    MessageBox.Show(
                        "No se encontraron registros para este reporte.",
                        "Información",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al generar el reporte:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =========================================================
        // LIMPIAR
        // =========================================================

        private void Limpiar()
        {
            dgvReportes.DataSource = null;

            if (cmbReporte.Items.Count > 0)
                cmbReporte.SelectedIndex = 0;

            CargarContadores();
        }

        private bool HayDatosParaExportar()
        {
            if (dgvReportes.DataSource == null ||
                dgvReportes.Rows.Count == 0)
            {
                MessageBox.Show(
                    "Primero debe generar un reporte con información.",
                    "Sin información",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        private string ObtenerValor(
            DataGridViewCell celda)
        {
            if (celda.Value == null ||
                celda.Value == DBNull.Value)
            {
                return "";
            }

            return Convert.ToString(celda.Value);
        }

        private string NombreArchivoReporte(string extension)
        {
            string nombre = cmbReporte.Text.Replace(" ", "_");

            foreach (char caracter in Path.GetInvalidFileNameChars())
                nombre = nombre.Replace(caracter, '_');

            return "Reporte_" + nombre + "_" +
                   DateTime.Now.ToString("yyyyMMdd_HHmmss") +
                   extension;
        }

        // =========================================================
        // EXPORTAR PDF CON MICROSOFT PRINT TO PDF
        // =========================================================

        private void ExportarPDF()
        {
            if (!HayDatosParaExportar())
                return;

            try
            {
                string impresoraPDF = "Microsoft Print to PDF";
                bool existeImpresora = false;

                foreach (string impresora in PrinterSettings.InstalledPrinters)
                {
                    if (string.Equals(
                        impresora,
                        impresoraPDF,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        existeImpresora = true;
                        break;
                    }
                }

                if (!existeImpresora)
                {
                    MessageBox.Show(
                        "No se encontró Microsoft Print to PDF.\n\n" +
                        "Verifique que la impresora esté instalada y habilitada " +
                        "en las características de Windows.",
                        "Impresora no disponible",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                using (SaveFileDialog guardar = new SaveFileDialog())
                {
                    guardar.Title = "Guardar reporte PDF";
                    guardar.Filter = "Documento PDF (*.pdf)|*.pdf";
                    guardar.FileName = NombreArchivoReporte(".pdf");
                    guardar.DefaultExt = "pdf";
                    guardar.AddExtension = true;
                    guardar.OverwritePrompt = true;

                    if (guardar.ShowDialog() != DialogResult.OK)
                        return;

                    gridImpresion = dgvReportes;
                    tituloImpresion = cmbReporte.Text;
                    indiceFilaImpresion = 0;
                    numeroPagina = 1;

                    using (documento = new PrintDocument())
                    {
                        documento.DocumentName = tituloImpresion;

                        documento.PrinterSettings.PrinterName =
                            impresoraPDF;

                        documento.PrinterSettings.PrintToFile = true;

                        documento.PrinterSettings.PrintFileName =
                            guardar.FileName;

                        documento.DefaultPageSettings.Landscape = true;
                        documento.DefaultPageSettings.Margins =
                            new Margins(40, 40, 50, 50);

                        documento.PrintPage += Documento_PrintPage;

                        documento.EndPrint += Documento_EndPrint;

                        documento.Print();

                        documento.PrintPage -= Documento_PrintPage;
                        documento.EndPrint -= Documento_EndPrint;
                    }

                    if (File.Exists(guardar.FileName))
                    {
                        MessageBox.Show(
                            "¡El reporte PDF se exportó correctamente!\n\n" +
                            "Archivo: " + Path.GetFileName(guardar.FileName) +
                            "\nUbicación: " + guardar.FileName,
                            "Exportación exitosa",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(
                            "La impresión finalizó, pero no se encontró el archivo PDF.\n\n" +
                            "Verifique la configuración de Microsoft Print to PDF.",
                            "No se confirmó el archivo",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al exportar el reporte PDF:\n" + ex.Message,
                    "Error PDF",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void Documento_PrintPage(
            object sender,
            PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;

            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;
            float ancho = e.MarginBounds.Width;

            using (DrawingFont fuenteSubtitulo =
                new DrawingFont("Arial", 10, FontStyle.Bold))
            using (DrawingFont fuentePie =
                new DrawingFont("Arial", 8))
            using (Pen linea = new Pen(DrawingColor.Gray, 1))
            using (SolidBrush pincelTexto =
                new SolidBrush(DrawingColor.Black))
            using (SolidBrush pincelEncabezado =
                new SolidBrush(DrawingColor.LightGray))
            {
                // Título
                g.DrawString(
                    "SIMMNI - SISTEMA DE MONITOREO DE MEDICAMENTOS",
                    fuenteTitulo,
                    pincelTexto,
                    x,
                    y);

                y += 35;

                g.DrawString(
                    "REPORTE: " + tituloImpresion,
                    fuenteSubtitulo,
                    pincelTexto,
                    x,
                    y);

                y += 22;

                g.DrawString(
                    "Fecha de generación: " +
                    DateTime.Now.ToString("dd/MM/yyyy HH:mm"),
                    fuenteNormal,
                    pincelTexto,
                    x,
                    y);

                y += 28;

                int columnas = gridImpresion.Columns.Count;

                if (columnas == 0)
                {
                    e.HasMorePages = false;
                    return;
                }

                float anchoColumna = ancho / columnas;
                float altoFila = 30;

                // Encabezados
                for (int c = 0; c < columnas; c++)
                {
                    RectangleF rectangulo = new RectangleF(
                        x + (c * anchoColumna),
                        y,
                        anchoColumna,
                        altoFila);

                    g.FillRectangle(pincelEncabezado, rectangulo);
                    g.DrawRectangle(
                        linea,
                        rectangulo.X,
                        rectangulo.Y,
                        rectangulo.Width,
                        rectangulo.Height);

                    string encabezado =
                        gridImpresion.Columns[c].HeaderText;

                    g.DrawString(
                        encabezado,
                        fuenteEncabezado,
                        pincelTexto,
                        rectangulo);
                }

                y += altoFila;

                // Filas
                while (indiceFilaImpresion < gridImpresion.Rows.Count)
                {
                    DataGridViewRow fila =
                        gridImpresion.Rows[indiceFilaImpresion];

                    if (fila.IsNewRow)
                    {
                        indiceFilaImpresion++;
                        continue;
                    }

                    if (y + altoFila > e.MarginBounds.Bottom - 35)
                    {
                        break;
                    }

                    for (int c = 0; c < columnas; c++)
                    {
                        RectangleF rectangulo = new RectangleF(
                            x + (c * anchoColumna),
                            y,
                            anchoColumna,
                            altoFila);

                        g.DrawRectangle(
                            linea,
                            rectangulo.X,
                            rectangulo.Y,
                            rectangulo.Width,
                            rectangulo.Height);

                        string valor = ObtenerValor(fila.Cells[c]);

                        StringFormat formato = new StringFormat();
                        formato.Trimming = StringTrimming.EllipsisCharacter;
                        formato.Alignment = StringAlignment.Near;
                        formato.LineAlignment = StringAlignment.Center;

                        g.DrawString(
                            valor,
                            fuenteNormal,
                            pincelTexto,
                            rectangulo,
                            formato);

                        formato.Dispose();
                    }

                    y += altoFila;
                    indiceFilaImpresion++;
                }

                // Pie de página
                g.DrawString(
                    "SIMMNI | Página " + numeroPagina,
                    fuentePie,
                    pincelTexto,
                    x,
                    e.MarginBounds.Bottom - 20);

                numeroPagina++;

                e.HasMorePages =
                    indiceFilaImpresion < gridImpresion.Rows.Count;
            }
        }

        private void Documento_EndPrint(
            object sender,
            PrintEventArgs e)
        {
            indiceFilaImpresion = 0;
        }

        // =========================================================
        // EXPORTAR EXCEL
        // =========================================================

        private void ExportarExcel()
        {
            if (!HayDatosParaExportar())
                return;

            try
            {
                using (SaveFileDialog guardar = new SaveFileDialog())
                {
                    guardar.Title = "Guardar reporte Excel";
                    guardar.Filter =
                        "Archivo de Excel (*.xlsx)|*.xlsx";

                    guardar.FileName =
                        NombreArchivoReporte(".xlsx");

                    guardar.DefaultExt = "xlsx";
                    guardar.AddExtension = true;
                    guardar.OverwritePrompt = true;

                    if (guardar.ShowDialog() != DialogResult.OK)
                        return;

                    using (XLWorkbook libro = new XLWorkbook())
                    {
                        DataTable tabla =
                            new DataTable("Reporte");

                        // Columnas
                        foreach (DataGridViewColumn columna
                            in dgvReportes.Columns)
                        {
                            if (columna.Visible)
                                tabla.Columns.Add(columna.HeaderText);
                        }

                        // Filas
                        foreach (DataGridViewRow fila
                            in dgvReportes.Rows)
                        {
                            if (fila.IsNewRow)
                                continue;

                            DataRow nuevaFila = tabla.NewRow();

                            int indice = 0;

                            foreach (DataGridViewColumn columna
                                in dgvReportes.Columns)
                            {
                                if (!columna.Visible)
                                    continue;

                                nuevaFila[indice] =
                                    ObtenerValor(fila.Cells[columna.Index]);

                                indice++;
                            }

                            tabla.Rows.Add(nuevaFila);
                        }

                        var hoja = libro.Worksheets.Add(tabla);

                        hoja.Row(1).Style.Font.Bold = true;
                        hoja.Row(1).Style.Fill.BackgroundColor =
                            XLColor.LightBlue;

                        hoja.Columns().AdjustToContents();

                        libro.SaveAs(guardar.FileName);
                    }

                    MessageBox.Show(
                        "¡El reporte Excel se exportó correctamente!\n\n" +
                        "Archivo: " + Path.GetFileName(guardar.FileName) +
                        "\nUbicación: " + guardar.FileName,
                        "Exportación exitosa",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al exportar a Excel:\n" + ex.Message,
                    "Error Excel",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =========================================================
        // EXPORTAR WORD
        // =========================================================

        private void ExportarWord()
        {
            if (!HayDatosParaExportar())
                return;

            try
            {
                using (SaveFileDialog guardar = new SaveFileDialog())
                {
                    guardar.Title = "Guardar reporte Word";
                    guardar.Filter =
                        "Documento Word (*.docx)|*.docx";

                    guardar.FileName =
                        NombreArchivoReporte(".docx");

                    guardar.DefaultExt = "docx";
                    guardar.AddExtension = true;
                    guardar.OverwritePrompt = true;

                    if (guardar.ShowDialog() != DialogResult.OK)
                        return;

                    using (WordprocessingDocument word =
                        WordprocessingDocument.Create(
                            guardar.FileName,
                            WordprocessingDocumentType.Document))
                    {
                        MainDocumentPart mainPart =
                            word.AddMainDocumentPart();

                        mainPart.Document = new WordDocument();

                        Body body = new Body();

                        Paragraph titulo = CrearParrafoWord(
                            "SIMMNI - SISTEMA DE MONITOREO DE MEDICAMENTOS",
                            true,
                            16);

                        body.Append(titulo);

                        body.Append(
                            CrearParrafoWord(
                                "REPORTE: " + cmbReporte.Text,
                                true,
                                13));

                        body.Append(
                            CrearParrafoWord(
                                "Fecha de generación: " +
                                DateTime.Now.ToString("dd/MM/yyyy HH:mm"),
                                false,
                                10));

                        body.Append(
                            CrearParrafoWord(" ", false, 10));

                        Table tabla = new Table();

                        TableProperties propiedades =
                            new TableProperties(
                                new TableBorders(
                                    new TopBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 6
                                    },
                                    new BottomBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 6
                                    },
                                    new LeftBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 6
                                    },
                                    new RightBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 6
                                    },
                                    new InsideHorizontalBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 4
                                    },
                                    new InsideVerticalBorder
                                    {
                                        Val = BorderValues.Single,
                                        Size = 4
                                    }));

                        tabla.AppendChild(propiedades);

                        // Encabezados
                        TableRow filaEncabezados = new TableRow();

                        foreach (DataGridViewColumn columna
                            in dgvReportes.Columns)
                        {
                            if (!columna.Visible)
                                continue;

                            filaEncabezados.Append(
                                CrearCeldaWord(
                                    columna.HeaderText,
                                    true));
                        }

                        tabla.Append(filaEncabezados);

                        // Datos
                        foreach (DataGridViewRow fila
                            in dgvReportes.Rows)
                        {
                            if (fila.IsNewRow)
                                continue;

                            TableRow nuevaFila = new TableRow();

                            foreach (DataGridViewColumn columna
                                in dgvReportes.Columns)
                            {
                                if (!columna.Visible)
                                    continue;

                                nuevaFila.Append(
                                    CrearCeldaWord(
                                        ObtenerValor(
                                            fila.Cells[columna.Index]),
                                        false));
                            }

                            tabla.Append(nuevaFila);
                        }

                        body.Append(tabla);

                        mainPart.Document.Append(body);
                        mainPart.Document.Save();
                    }

                    MessageBox.Show(
                        "¡El reporte Word se exportó correctamente!\n\n" +
                        "Archivo: " + Path.GetFileName(guardar.FileName) +
                        "\nUbicación: " + guardar.FileName,
                        "Exportación exitosa",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al exportar a Word:\n" + ex.Message,
                    "Error Word",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private Paragraph CrearParrafoWord(
            string texto,
            bool negrita,
            int tamano)
        {
            RunProperties propiedades = new RunProperties();

            propiedades.Append(
                new FontSize
                {
                    Val = (tamano * 2).ToString()
                });

            if (negrita)
                propiedades.Append(new Bold());

            Run run = new Run();

            run.Append(propiedades);

            run.Append(
                new WordText(texto)
                {
                    Space = SpaceProcessingModeValues.Preserve
                });

            Paragraph parrafo = new Paragraph();
            parrafo.Append(run);

            return parrafo;
        }

        private TableCell CrearCeldaWord(
            string texto,
            bool encabezado)
        {
            Paragraph parrafo = CrearParrafoWord(
                texto,
                encabezado,
                9);

            TableCell celda = new TableCell();

            if (encabezado)
            {
                TableCellProperties propiedades =
                    new TableCellProperties(
                        new Shading
                        {
                            Fill = "D9EAF7",
                            Val = ShadingPatternValues.Clear
                        });

                celda.Append(propiedades);
            }

            celda.Append(parrafo);

            return celda;
        }

        // =========================================================
        // EVENTOS DE LOS BOTONES
        // =========================================================

        private void btnGenerar_Click(
            object sender,
            EventArgs e)
        {
            GenerarReporte();
        }

        private void btnLimpiar_Click(
            object sender,
            EventArgs e)
        {
            Limpiar();
        }

        private void btnExportarPDF_Click(
            object sender,
            EventArgs e)
        {
            ExportarPDF();
        }

        private void btnExportarExcel_Click(
            object sender,
            EventArgs e)
        {
            ExportarExcel();
        }

        private void btnExportarWord_Click(
            object sender,
            EventArgs e)
        {
            ExportarWord();
        }
    }
}
