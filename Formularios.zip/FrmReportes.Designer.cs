﻿using System.Drawing;
using System.Windows.Forms;

namespace SIMMNI.Formularios
{
    partial class FrmReportes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle estilo1 = new DataGridViewCellStyle();
            DataGridViewCellStyle estilo2 = new DataGridViewCellStyle();
            DataGridViewCellStyle estilo3 = new DataGridViewCellStyle();
            DataGridViewCellStyle estilo4 = new DataGridViewCellStyle();

            lblTitulo = new Label();
            lblFiltro = new Label();
            lblTotalPacientes = new Label();
            lblTotalMedicamentos = new Label();
            lblTotalHistorial = new Label();

            cmbReporte = new ComboBox();

            btnGenerar = new Button();
            btnExportarPDF = new Button();
            btnExportarExcel = new Button();
            btnExportarWord = new Button();
            btnLimpiar = new Button();

            dgvReportes = new DataGridView();

            ((System.ComponentModel.ISupportInitialize)dgvReportes).BeginInit();
            SuspendLayout();

            // TITULO

            lblTitulo.Anchor = AnchorStyles.Top;
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            lblTitulo.Location = new Point(601, 9);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(337, 38);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "REPORTES DEL SISTEMA";

            // FILTRO

            lblFiltro.AutoSize = true;
            lblFiltro.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblFiltro.Location = new Point(40, 70);
            lblFiltro.Name = "lblFiltro";
            lblFiltro.Size = new Size(160, 28);
            lblFiltro.TabIndex = 1;
            lblFiltro.Text = "Tipo de reporte";

            // TOTAL PACIENTES

            lblTotalPacientes.AutoSize = true;
            lblTotalPacientes.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTotalPacientes.Location = new Point(20, 188);
            lblTotalPacientes.Name = "lblTotalPacientes";
            lblTotalPacientes.Size = new Size(178, 28);
            lblTotalPacientes.TabIndex = 6;
            lblTotalPacientes.Text = "Total Pacientes: 0";

            // TOTAL MEDICAMENTOS

            lblTotalMedicamentos.AutoSize = true;
            lblTotalMedicamentos.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTotalMedicamentos.Location = new Point(679, 188);
            lblTotalMedicamentos.Name = "lblTotalMedicamentos";
            lblTotalMedicamentos.Size = new Size(227, 28);
            lblTotalMedicamentos.TabIndex = 7;
            lblTotalMedicamentos.Text = "Total Medicamentos: 0";

            // TOTAL HISTORIAL

            lblTotalHistorial.AutoSize = true;
            lblTotalHistorial.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTotalHistorial.Location = new Point(1351, 188);
            lblTotalHistorial.Name = "lblTotalHistorial";
            lblTotalHistorial.Size = new Size(169, 28);
            lblTotalHistorial.TabIndex = 8;
            lblTotalHistorial.Text = "Total Historial: 0";

            // COMBOBOX

            cmbReporte.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbReporte.Font = new Font("Segoe UI", 12F);

            cmbReporte.Items.AddRange(new object[]
            {
                "Pacientes registrados",
                "Padecimientos registrados",
                "Medicamentos registrados",
                "Historial de tomas",
                "Medicamentos próximos a vencer",
                "Medicamentos vencidos"
            });

            cmbReporte.Location = new Point(40, 110);
            cmbReporte.Name = "cmbReporte";
            cmbReporte.Size = new Size(450, 36);
            cmbReporte.TabIndex = 2;

            // BOTON LIMPIAR

            btnLimpiar.BackColor = Color.SteelBlue;
            btnLimpiar.FlatAppearance.BorderSize = 0;
            btnLimpiar.FlatStyle = FlatStyle.Flat;
            btnLimpiar.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnLimpiar.ForeColor = Color.White;
            btnLimpiar.Location = new Point(510, 96);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(130, 50);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "LIMPIAR";
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;

            // BOTON GENERAR

            btnGenerar.BackColor = Color.FromArgb(41, 91, 140);
            btnGenerar.FlatAppearance.BorderSize = 0;
            btnGenerar.FlatStyle = FlatStyle.Flat;
            btnGenerar.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnGenerar.ForeColor = Color.White;
            btnGenerar.Location = new Point(655, 96);
            btnGenerar.Name = "btnGenerar";
            btnGenerar.Size = new Size(145, 50);
            btnGenerar.TabIndex = 4;
            btnGenerar.Text = "GENERAR";
            btnGenerar.UseVisualStyleBackColor = false;
            btnGenerar.Click += btnGenerar_Click;

            // BOTON PDF

            btnExportarPDF.BackColor = Color.FromArgb(166, 55, 55);
            btnExportarPDF.FlatAppearance.BorderSize = 0;
            btnExportarPDF.FlatStyle = FlatStyle.Flat;
            btnExportarPDF.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnExportarPDF.ForeColor = Color.White;
            btnExportarPDF.Location = new Point(815, 96);
            btnExportarPDF.Name = "btnExportarPDF";
            btnExportarPDF.Size = new Size(120, 50);
            btnExportarPDF.TabIndex = 5;
            btnExportarPDF.Text = "PDF";
            btnExportarPDF.UseVisualStyleBackColor = false;
            btnExportarPDF.Click += btnExportarPDF_Click;

            // BOTON EXCEL

            btnExportarExcel.BackColor = Color.FromArgb(35, 120, 78);
            btnExportarExcel.FlatAppearance.BorderSize = 0;
            btnExportarExcel.FlatStyle = FlatStyle.Flat;
            btnExportarExcel.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnExportarExcel.ForeColor = Color.White;
            btnExportarExcel.Location = new Point(950, 96);
            btnExportarExcel.Name = "btnExportarExcel";
            btnExportarExcel.Size = new Size(130, 50);
            btnExportarExcel.TabIndex = 6;
            btnExportarExcel.Text = "EXCEL";
            btnExportarExcel.UseVisualStyleBackColor = false;
            btnExportarExcel.Click += btnExportarExcel_Click;

            // BOTON WORD

            btnExportarWord.BackColor = Color.FromArgb(43, 84, 145);
            btnExportarWord.FlatAppearance.BorderSize = 0;
            btnExportarWord.FlatStyle = FlatStyle.Flat;
            btnExportarWord.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnExportarWord.ForeColor = Color.White;
            btnExportarWord.Location = new Point(1095, 96);
            btnExportarWord.Name = "btnExportarWord";
            btnExportarWord.Size = new Size(130, 50);
            btnExportarWord.TabIndex = 7;
            btnExportarWord.Text = "WORD";
            btnExportarWord.UseVisualStyleBackColor = false;
            btnExportarWord.Click += btnExportarWord_Click;

            // DATAGRIDVIEW

            dgvReportes.AllowUserToAddRows = false;
            dgvReportes.AllowUserToDeleteRows = false;

            estilo1.BackColor = Color.FromArgb(236, 240, 241);
            dgvReportes.AlternatingRowsDefaultCellStyle = estilo1;

            dgvReportes.Anchor = AnchorStyles.Top |
                                 AnchorStyles.Bottom |
                                 AnchorStyles.Left |
                                 AnchorStyles.Right;

            dgvReportes.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvReportes.BackgroundColor = Color.White;
            dgvReportes.BorderStyle = BorderStyle.None;

            estilo2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            estilo2.BackColor = Color.FromArgb(52, 73, 94);
            estilo2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            estilo2.ForeColor = Color.White;
            estilo2.SelectionBackColor = SystemColors.Highlight;
            estilo2.SelectionForeColor = SystemColors.HighlightText;
            estilo2.WrapMode = DataGridViewTriState.True;

            dgvReportes.ColumnHeadersDefaultCellStyle = estilo2;
            dgvReportes.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            estilo3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            estilo3.BackColor = SystemColors.Window;
            estilo3.Font = new Font("Segoe UI", 10F);
            estilo3.ForeColor = SystemColors.ControlText;
            estilo3.SelectionBackColor = Color.FromArgb(52, 152, 219);
            estilo3.SelectionForeColor = Color.White;
            estilo3.WrapMode = DataGridViewTriState.False;

            dgvReportes.DefaultCellStyle = estilo3;
            dgvReportes.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvReportes.EnableHeadersVisualStyles = false;
            dgvReportes.Location = new Point(20, 229);
            dgvReportes.MultiSelect = false;
            dgvReportes.Name = "dgvReportes";
            dgvReportes.ReadOnly = true;
            dgvReportes.RowHeadersVisible = false;
            dgvReportes.RowHeadersWidth = 51;

            estilo4.BackColor = Color.White;
            dgvReportes.RowsDefaultCellStyle = estilo4;

            dgvReportes.RowTemplate.Height = 30;

            dgvReportes.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvReportes.Size = new Size(1500, 412);
            dgvReportes.TabIndex = 8;

            // FORMULARIO

            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1540, 653);

            Controls.Add(dgvReportes);
            Controls.Add(btnExportarWord);
            Controls.Add(btnExportarExcel);
            Controls.Add(btnExportarPDF);
            Controls.Add(btnLimpiar);
            Controls.Add(btnGenerar);
            Controls.Add(cmbReporte);
            Controls.Add(lblFiltro);
            Controls.Add(lblTitulo);
            Controls.Add(lblTotalHistorial);
            Controls.Add(lblTotalMedicamentos);
            Controls.Add(lblTotalPacientes);

            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            MinimumSize = new Size(1200, 700);

            Name = "FrmReportes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reportes";
            WindowState = FormWindowState.Maximized;

            Load += FrmReportes_Load;

            ((System.ComponentModel.ISupportInitialize)dgvReportes).EndInit();

            ResumeLayout(false);
            PerformLayout();
        }

        // CONTROLES

        private Label lblTitulo;
        private Label lblFiltro;

        private ComboBox cmbReporte;

        private Button btnGenerar;
        private Button btnLimpiar;

        private Button btnExportarPDF;
        private Button btnExportarExcel;
        private Button btnExportarWord;

        private Label lblTotalPacientes;
        private Label lblTotalMedicamentos;
        private Label lblTotalHistorial;

        private DataGridView dgvReportes;
    }
}